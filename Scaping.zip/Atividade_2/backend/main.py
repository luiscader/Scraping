from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from bs4 import BeautifulSoup
import httpx
import os
from urllib.parse import urljoin, urlparse

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class ScrapeRequest(BaseModel):
    url: str

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept-Language": "en-US,en;q=0.5",
}

@app.post("/api/scrape")
async def scrape(request: ScrapeRequest):
    try:
        url = request.url

        async with httpx.AsyncClient(headers=headers) as client:
            response = await client.get(url, timeout=10)

        if response.status_code != 200:
            raise HTTPException(status_code=response.status_code, detail="Erro ao acessar o site")

        content = response.content
        soup = BeautifulSoup(content, "html.parser")

        all_texts = [text.strip() for text in soup.stripped_strings if text.strip()]

        images = set()
        for img in soup.find_all("img"):
            src = img.get("src")
            if src:
                full_url = urljoin(url, src)
                if urlparse(full_url).scheme in ["http", "https"]:
                    images.add(full_url)

        style_elements = soup.find_all("style")
        inline_styles = "".join(style.string for style in style_elements if style.string)

        css_links = [urljoin(url, link["href"]) for link in soup.find_all("link", {"rel": "stylesheet"}) if link.get("href")]
        css_content = ""
        async with httpx.AsyncClient(headers=headers) as client:
            for css_link in css_links:
                if urlparse(css_link).scheme in ["http", "https"]:
                    css_response = await client.get(css_link)
                    if css_response.status_code == 200:
                        css_content += css_response.text

        soup.head.append(BeautifulSoup(f'<style>{inline_styles}</style>', "html.parser"))
        soup.head.append(BeautifulSoup(f'<style>{css_content}</style>', "html.parser"))

        response_data = {
            "html": soup.prettify(),
            "texts": all_texts if all_texts else ["Nenhum texto encontrado."],
            "images": list(images) if images else [],
        }

        return response_data

    except httpx.RequestError:
        raise HTTPException(status_code=500, detail="Erro de requisição HTTP")
    except Exception:
        raise HTTPException(status_code=500, detail="Erro durante o scraping")

frontend_path = os.path.join(os.path.dirname(__file__), '../frontend')

app.mount("/", StaticFiles(directory=frontend_path, html=True), name="frontend")
